require('dotenv').config();
const { Telegraf } = require('telegraf');
const Binance = require('node-binance-api');
const axios = require('axios');

const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN);
const binance = new Binance().options({
  APIKEY: process.env.BINANCE_API_KEY,
  APISECRET: process.env.BINANCE_API_SECRET,
  useServerTime: true,
  test: false
});

const userId = process.env.TELEGRAM_USER_ID;

bot.start((ctx) => {
  if (ctx.from.id.toString() !== userId) return;
  ctx.reply('✅ Bot is running! Use /signal to get a signal.');
});

bot.command('ping', (ctx) => {
  if (ctx.from.id.toString() !== userId) return;
  ctx.reply('Pong!');
});

bot.command('signal', async (ctx) => {
  if (ctx.from.id.toString() !== userId) return;
  try {
    const prices = await binance.futuresPrices();
    const btcPrice = prices['BTCUSDT'];
    ctx.reply(`Current BTC price: $${btcPrice}`);
  } catch (err) {
    ctx.reply('Error fetching signal.');
  }
});

bot.launch();
console.log("Bot is running...");
